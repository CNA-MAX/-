//#ifndef __SHA256_H
//#define __SHA256_H	 
//#include "sys.h"
//  char* StrSHA256(  uint8_t *str, uint64_t length, uint8_t* sha256);
//#endif
#ifndef SHA256_H
#define SHA256_H

/*************************** HEADER FILES ***************************/
#include <stddef.h>
#include <string.h>

/****************************** MACROS ******************************/
#define SHA256_BLOCK_SIZE 32            // SHA256输出32字节的摘要

/**************************** DATA TYPES ****************************/
typedef unsigned char BYTE;             // BYTE代表unsigned
typedef unsigned int  SHA256_WORD;             // word代表int

typedef struct {
	BYTE data[64];  // 当前的512位消息数据块，就像缓冲区一样
	SHA256_WORD datalen;   // 为当前块的数据长度签名
	unsigned long long bitlen;  // 总消息的位长
	SHA256_WORD state[8];  // 存储哈希抽象的中间状态
} SHA256_CTX;

/*********************** FUNCTION DECLARATIONS **********************/
void sha256_init(SHA256_CTX *ctx);
void sha256_update(SHA256_CTX *ctx,  BYTE data[], size_t len);
void sha256_final(SHA256_CTX *ctx, BYTE hash[],int identify);
void Sha256_test(void);
int ertification_pass(void);
#endif   // SHA256_H



